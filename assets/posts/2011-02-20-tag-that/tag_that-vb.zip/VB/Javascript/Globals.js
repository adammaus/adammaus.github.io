// Tag That
// Version 1.0
// Programming done by Adam Maus
// "Sponsored" by the Center for Health Enhancement Systems Studies
// Feel free to adapt this code anyway you please

//I tried to get all the global variables into one file, the other files do certain functions
//Trap_Keys.js takes care of all the functions that deal with typing on the keyboard
//AjaxTags.js takes care of getting the tags and returning results to a div
//Js_Tags.js is involved in processing the tags and putting them into tree format

var numResults = 5;															//Number of results to show
var ImageLocation = "Images/close_box.gif"; 		//Where the Close Box Image Is
var DefaultSearchBoxTextColor = '#000000';
var highlightColor = "#DBDBDB"; 								//Color of highlight for Table Row
var inactiveColor = "#EBEBEB";									//Color of row when inactive

//DO NOT EDIT BELOW THIS LINE
//Set the results to false, we do not have any results at the moment, set the tab to 0 because we do not have results and are at the search box when we first tab
var results = false;
var tab = 0;
var gotTags = false;	//Tells us if we got the tags yet and can start searching
var tagArr=[];

//This function replaces document.getElementById with $ making code easier to read and write
function $(elementID) {
    return document.getElementById(elementID);
}

//A handy diagnostic tool that opens a new window so that you can study the DOM structure of an element
function diagnostic(elem, showValues){
	// Diagnostic
	var str = "";
	str += "<h5>" + elem + "</h5>";
	for (var key in elem){
		str += "\n<br />" + key;
		if (showValues || key == 0){
			str += ": " + elem[key];
		}
	}
	my_window= window.open ("","mywindow1","status=1,width=350,height=400,scrollbars=yes"); 
	my_window.document.write(str);
}

// -----------------------------------------
//                  trim
// Trim leading/trailing whitespace off string
// -----------------------------------------
function trim(str){
  return str.replace(/^\s+|\s+$/g, '')
};

function RemoveEmptyCommas(){
	//Normalize (remove empty commas) the current value of the tags
	//This looks for any two or more commas in a row and replaces them with one
	//Then it removes any trailing commas
	$("tags").value = $("tags").value.replace(/,+/g,",").replace(/,$/g,"");
}