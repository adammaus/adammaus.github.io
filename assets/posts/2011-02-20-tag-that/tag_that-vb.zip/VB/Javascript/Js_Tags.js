// This contains all the functions needed to render the table for auto-suggest tags in story database

// "$" replaces document.getElementById and can be found in globals

// function: addStoryTag()
// adds the tag to the hidden field and adds the span box
function addStoryTag(){
	var AddTagArr = ($("tagsText").value).split(",");
	// In case they decide to add multiple tags at a time...
	var i = 0;
	while (i < AddTagArr.length){
		var tag = trim(AddTagArr[i]);
		//Search old tags and if found, do not add new tag
		if (IndexOfTag(tag) == -1){
			// Not Found, add new tag and write the html
			$("tags").value += "," + tag + ",";
			// Increment the current tag number and add the tag
			
			html = "<span id=\"TagBox"+CurrentTagNumber+"\" class=\"TagBox\">";
			html += tag;
			html += " <a href=\"#\" onclick=\"removeStoryTag("+CurrentTagNumber+"); return false;\"><img src=\"" + ImageLocation + "\" border=\"0\" width=\"10\" height=\"10\" /></a>";
			html += "<input type=\"hidden\" id=\"HiddenTag"+CurrentTagNumber+"\" value=\""+tag+"\" /></span>";
			// Add the new tag to the div
			$("CurrentTags").innerHTML += html;
			CurrentTagNumber += 1;
		}
		i = i + 1;
	}
	//Empty the tag box
	$("tagsText").value = "";
	$("tagResults").innerHTML = "";
	results = false;
	tab = 0;
	
	//Normalize the Tag Hidden field so there are no empty tags
	RemoveEmptyCommas()
}

// Climbs the associative array tree and finds/returns nodes
// Need to define a global variable that will hold results
var ResultsKnapSack = "";
var MaxTabs = 0;
function climbTree(tree, term){
	if (term == ""){
		// Found the end of the term
		// Begin climbing the branches of our tree and getting possible future nodes (fruit, yummy, especially strawberries which coincidentally only grows on bushes not trees)
		var bush = tree;		//Lets just be environmentally correct
		// If the bush has a fruit, grab it and put it in our resultsknapsack
		if (bush.length != 0){
			// I have absolutely no idea how there will be more than 1 result 
			// in each array but miracles can happen (mutations)
			// This was found to happen when there was a tag with 123ABC, it produced two null values
			// We check to make sure there aren't any null values being added to the results
			if (bush[0] != null){
				ResultsKnapSack += bush[0] + ",";
			}
		}
		// True Recursion at work
		// Look at future branches that can be found in the bush that can be searched
		for (branch in bush){
			if (branch != 0){
				climbTree(bush[branch], "");		//Null will get us back to this stage right away
			}
		}
		return;
	}
	// Search the tree by slicing off the first character and searching that subtree
	// For example:  term = abc
	// Look at tree, inspect branch with "a", slice off the "a" and term = bc after first step
	// Repeat, inspect branch with "b", slice off the "b" and term = c after 2nd step
	// Once you reach the end of the term, start looking at possible future tags
	var currChar = term.slice(0,1).toString();
	try {
		climbTree(tree[currChar], term.slice(1));
	} catch (e){
		// The end of the string was not reached but tree[currChar] is invalid
		// or there are No Results
	}
	return;
}

// function: createTable(tags, chars, numResults)
// renders the table of tags, involves showing the characters typed highlighted
// only takes the specified number of tags return the html table
// tree is an associative array to search for the string
// chars is the current term being searched
// numResults is the number of results to show
function createTable(tree, term, numResults){
	html = "<table cellpadding=\"0\" cellspacing=\"0\" id=\"tagsTable\">";
	
	ResultsKnapSack = "";
	climbTree(tree, term);
	// Have the fruit (terms) in our knapsack (results)
	
	// This section of code checks if the term is either in the results data or if it is already a tag
	var NoTerms = ""
	if (ResultsKnapSack.split(",").indexOf(term) != -1 ||  IndexOfTag(term) != -1){
		NoTerms = ": \"" + term + "\" is already a tag";
	}

	var closeTd = "</td>\r\n</tr class=\"trStyle\">";
	var openLink = ""; // To be defined later
	var closeLink = "</span></a>";
	if (ResultsKnapSack != ""){
		// Split the results by ,
		var results = ResultsKnapSack.split(",");
		//Results should already be sorted but if they are not, do the below function
		//var results = results.sort();
		var i = 0;
		var k = 0;
		while (i < results.length && k < numResults){
			var result = trim(results[i]);
			if (result != "" && IndexOfTag(result) == -1){
				var openTd = "<tr class=\"trStyle\">\r\n<td id=\"tr"+(k+1)+"\"class=\"tdStyle\">\r\n\t";
				openLink = "<a href=\"#\" id=\"link"+(k+1)+"\" onclick=\"javascript:$('tagsText').value='"+results[i]+"';addStoryTag();return false;\" class=\"linkStyle\"><span class=\"highlight\" id=\"SpanTag"+(k+1)+"\">";
				//Build the html for each row
				html += openTd;
				html += openLink;
				html += trim(results[i]);
				html += closeLink;
				html += closeTd;
				k = k + 1;
			}
			i = i + 1;
		}
		MaxTabs = k;
		if (k == 0){
			var openTd = "<tr class=\"trStyle\">\r\n<td class=\"tdStyle\">\r\n\t";
			html += openTd;
			html += "<span class=\"noResultsStyle\">No Results" + NoTerms + "</span>";
			html += closeTd;
		}
	} else {
		var openTd = "<tr class=\"trStyle\">\r\n<td class=\"tdStyle\">\r\n\t";
		html += openTd;
		html += "<span class=\"noResultsStyle\">No Results" + NoTerms + "</span>";
		html += closeTd;
	}
	html += "</table>";
	return html;
}

// Index Of Tag
// Look at the current tags in the hidden input field and find the index of the current tag
// If the tag is not there, return -1
function IndexOfTag(tag){
	var curr_tags = (trim($("tags").value)).split(",");
	var j = 0;
	while (j < curr_tags.length){
		var curr_tag = trim(curr_tags[j]);
		if (tag == curr_tag){
			//Found the tag, do not add this tag
			return j;
		}
		j = j + 1;
	}
	return -1;
}

// function: removeTags(tagNum)
// removes the span box and the tag from the hidden field
function removeStoryTag(tagNum){
	var SearchTag = trim($("HiddenTag" + tagNum).value);			//Get the tag
	//Search through the hidden tag string and remove the value
	var curr_tags = trim($("tags").value);
	if (curr_tags != ""){
		var tagArr = curr_tags.split(",");
		var i = 0;
		while (i < tagArr.length){
			tagArr[i] = trim(tagArr[i]);
			var tag = trim(tagArr[i]);
			if (tag == SearchTag){
				//Found the tag, remove
				tagArr.splice(i, 1);
				i = tagArr.length;
			}
			i = i + 1;
		}
		$("tags").value = tagArr.join(",");						// Reset the value of the tags to the new one
		$("TagBox"+tagNum).style.display = "none";		// Remove the TagBox
		$("TagBox"+tagNum).innerHTML = "";
	}
}