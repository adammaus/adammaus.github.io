﻿<?php  
//$arr = GetTags()
//In this test, I am going to use a variable call strArr to store the test tags
//In an actual environment, you will have to either get the tags from a database or specify them in the strArr
$strArr = array("test", "ab", "testing", "tests", "testify", "abc", "abe", "query", "  whale", "whales", "what", "what what","123ABC", "23ABC", "null", "undefined");
?>
<script type="text/javascript">
// Functions for creating and printing the tree
function addTag(arr, str, charNum){
	if (charNum < str.length){
		key = str.charAt(charNum);
		try {
			if (str.substring(charNum, charNum+6) == "&nbsp;"){
				key = "&nbsp;";
				charNum = charNum + 5;
			}
		} catch (e) {
			// do nothing, we do not have a &nbsp;
		}
		
		try {
			if (arr[key] != "" && arr[key].length == 0){
				arr[key][arr[key].length] = [];
			}
		} catch (e) {
			arr[key] = [];
		}
		arr[key] = addTag(arr[key], str, charNum+1);
		return arr;
	} else {
		return [str];	//We have completed a tag, so return the entire word
	}
}
// This is a diagnostic function for print the contents of the tree
function printTags(arr, offset){
	if (arr[0] != "" && arr[0] != null){
		var i = 0;
		while (i < offset){
			document.write("&nbsp;&nbsp;&nbsp;");
			i = i + 1;
		}
		document.write("<span style=\"color:red;\">" + arr[0] + "</span>" + "<br />");
	}
	for (key in arr){
		if (key != 0){
			var i = 0;
			while (i < offset){
				document.write("&nbsp;&nbsp;&nbsp;");
				i = i + 1;
			}
			document.write(key + "<br />");
			try {
				printTags(arr[key],offset+1);
			} catch (e) {
				// do nothing
			}
		}
	}
	
}

var tempTags = [];
<?php 
$k = 0;
$tag = "";
$nextChar = "";
if (isset($arr)){
	foreach ($arr as $row){
		$tag = $row["tag"];
?>
tempTags[<?php echo $k; ?>]=trim("<?php echo $tag; ?>").replace(" ", "&nbsp;");
<?php 
		$k = $k + 1;
	}
} else {
	while ($k < count($strArr)){
		$tag = $strArr[$k];
?>
tempTags[<?php echo $k; ?>]=trim("<?php echo $tag; ?>").replace(" ", "&nbsp;");
<?php
		$k = $k + 1;
	}
}
?>
//After we have constructed the tag array, we can build the tree using the above function
tags = [];
var i = 0;
while (i < tempTags.length){
	tags = addTag(tags, tempTags[i], 0);
	i = i + 1;
}

tagArr = tags;
</script>