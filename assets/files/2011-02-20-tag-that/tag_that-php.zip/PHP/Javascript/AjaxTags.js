function getTags() {
	//AJAXRequest(GET|POST, FILE_TO_PROCESS, DATA_TO_SEND, FUNCTION_TO_CALL_AFTER_RESPONSE, null=ASYNC_COMMUNICATION_WITH_SERVER, DIV_TO_PLACE_RESPONSE_DATA)
	//If you wanted to send data
	// var sData = 'var1=blah&var2=blah';
	var ajax = AJAXRequest("post","Include/GetTags.php","",updateContent,null,"");
}

//This is the code that ajax calls when it is getting a response and after it gets a response from the server
//  It evaluates the JS in the response page since browser does not evaluate it, it treats as static text
//  If a DivID is specified, the response is then loaded into the div
function updateContent(text, divID) {
	var evaledJS = evaluateJS(text);
	if (divID!=""){
		$(divID).innerHTML=text;
	}
}

//Getting information back from the AJAX call, we need to evaluate any javascript
function evaluateJS(text){
	// If there is no javascript, return nothing
	var start = text.match(/<script .*javascript.*>?/);
	if (start == -1){
		return;
	}
	// Use regular expression to split up the response text into chunks of code
	// Evaluation will happen like it does in the browser	
	var jsArr = text.split(/<script .*javascript.*>?/ig);
	// Cycle through the Javascript Array and evaluate each of the script items
	var i = 0;
	//Eval can rewrite variables so using a for loop is a better iterator than while in this case
	for (key in jsArr){
		//Look for the code, if it does not have a closing tag, then it probably is not code
		if (jsArr[key].match(/<\/script>/)){
			//Take the first chunk of code, not any other text
			var code = jsArr[key].split(/<\/script>/i);
			eval(code[0]);
		}
	}
	return;
}

//-----------------------AJAX Commands------------------------------
// use: ajaxObj = GetXmlHttpObject();
function GetXmlHttpObject(){
	var obj = null;
	try {
		obj = new ActiveXObject("Msxml2.XMLHTTP");
	} catch(e) {
		try{
			obj = new ActiveXObject("Microsoft.XMLHTTP");
		} catch(e2) {
			obj = null;
		}
	}
	if(!obj && typeof XMLHttpRequest != "undefined") {
		obj = new XMLHttpRequest();
	}
	return obj;
}

function AJAXRequest( method, url, data, process, async, target ) {
    var self = this;
	self.targetID = target;
	self.AJAX = GetXmlHttpObject();
	self.process = process;

	// create an anonymous function to log state changes
	self.AJAX.onreadystatechange = function( ) {
		//self.process(self.AJAX);
		if (self.AJAX.readyState == 4) {
			if (self.AJAX.status == 200) {
				if ( self.AJAX.responseText ) {
					//if (self.process=='undefined' || self.process==null) {
					if (!self.process) {
						eval(self.AJAX.responseText);
					} else {
						self.process(self.AJAX.responseText, self.targetID);
					}
				}
			}
		}
	}

	// if no method specified, then default to POST
	if (!method) {
		method = "POST";
	} else {
		method = method.toUpperCase();
	}

	if (typeof async == 'undefined' || async == null) {
		async = true;
	}
 	
	self.AJAX.open(method, url, async);
	
	if (method == "POST") {
		self.AJAX.setRequestHeader("Connection", "close");
		self.AJAX.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		self.AJAX.setRequestHeader("Method", "POST " + url + "HTTP/1.1");
	}
   
	if ( !data ) data=""; 
	
	self.AJAX.send(data);

	return self.AJAX;
}