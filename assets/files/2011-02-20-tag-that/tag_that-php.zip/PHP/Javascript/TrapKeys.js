//============================trap keys=================================================
//    kcode = 40        down
//            38        up
//            13        enter

//Stop the propagation of the down/up arrow that is commonly used in browsers to move the page down.  If the results are there, this will allow the user to stay within the table and scroll through the results one by one.
document.onkeydown = function(e){ 	//This code runs when a user presses a button
	if(isIE()){												//Check the browser
		e = window.event; 							//IE uses window.event as an event
		kCode = e.keyCode;							
		//Once the key code is gotten, we check to see if there are already results (from a previous search)
		// If the user presses up, down, or enter, we cancel the event and remove default behavior
		if (results && (kCode == 40 || kCode == 38 || kCode == 13)){
			event.cancelBubble = false;
			event.returnValue = false;
		}
	}	else {
		// All other browsers use another event type
		window.onkeypress=function(e){	//In addition to to the key down, use key press to get the event
			g = e.keyCode; 								//Get the keycode
			// If the user presses up, down, or enter, we cancel the event and remove default behavior
			if(g==40 || g==38 || g==13){ 
				e.preventDefault();
				e.stopPropagation();
				return false; 
			} 
		};
	}
}
document.onkeyup = getKey;
/////

function getKey(ev) { 
	ev = ev || window.event;             	// gets the event in ie or ns 
  kCode = ev.keyCode || ev.which;   		// gets the keycode in ie or ns
	//Only run these functions if there are results in the div
	if (results && (kCode == 40 || kCode == 38)){
		if (kCode == 40){		//If the user pressed the Down Key
			resultKeyDown();
		} else if (kCode == 38)  { 
			resultKeyUp();		//If the user pressed the Up Key
		}
	}
	
	//If the user pressed the enter key
	if (results && kCode == 13){
		//We have to "click" on the link and add it to the search box
		var clickFlag = true;
		try {
			$('link'+tab).click();	//Default behavior for IE
			clickFlag = false;
		} catch(e){
			try {
				$('link'+tab).onclick();	//Default behavior for Firefox
				clickFlag = false;
			} catch(e){
				// do nothing, probably just focused on search
			}
		}
		if (tab == 0 && clickFlag){
			addStoryTag();						//Add the story tag that is the "search box"
			$("tagsText").focus();		//Focus on the "search box" again
		}
	}
} 

//If we have results, we run this function that moves the highlight between rows of the table
//This one allows us to use the keyup feature.
//When focused on the search box, it goes to the last row and then continues up
//When focused on the first row, it then focuses on the search box
function resultKeyUp(){
	if (tab == 0){
		tab = MaxTabs+1;
	}
	if (tab >= 1){
		try {
			// Unhighlight the current row we are on
			$('tr'+tab).style.backgroundColor=inactiveColor;
		} catch (e){
			// We are in the search bar blur it and focus on the last row
			$('tagsText').blur();
		}
	}
	tab = tab - 1;
	//Highlight the background of the row we are on
	try {
		$('tr'+tab).style.backgroundColor=highlightColor;
	} catch(e){
		//If we are not a row, then focus on the search box
		$('tagsText').focus();
		tab = 0;
	}
}
//If we have results, we run this function that moves the highlight between rows of the table
//This one allows us to use the keydown feature.
//When focused on the search box, it goes to the 1st row and then continues down
//When focused on the last row, it then focuses on the search box
function resultKeyDown(){
	if (tab <= 0){
		try {
			$('tagsText').focus();
			tab = 0;
		} catch(e){
			//Do Nothing
		}
	}
	// Unhighlight the current row
	if (tab >= 1){
		$('tr'+tab).style.backgroundColor=inactiveColor;
	}
	tab = tab + 1;
	// Highlight the new row
	try {
		$('tr'+tab).style.backgroundColor=highlightColor;
		$('tagsText').blur();	//If we are in the search box, blur the box
	} catch(e){
		//If we are not a row, then focus on the search box
		tab = 0;
		$('tagsText').focus();
	}
}

//Determines if a browser is an IE browser or not
//Returns false if the browser is not IE, returns true if it is IE
function isIE(){  
	return /msie/i.test(navigator.userAgent) && !/opera/i.test(navigator.userAgent);
}

/////   ONKEYUP main ajax call for SEARCHBOX
function loadResults(term, numResults, ev){
	ev = ev || window.event;				 // gets the event in ie or ns 
	kCode = ev.keyCode || ev.which;	 // gets the keycode in ie or ns
	if (term == 0) {
		$("tagResults").innerHTML = '';   // "$" is a shortcut to document.getElementByID: 
																	 		// this sets the "results" DIV aboove to nothing 
																			// $ is specified in AjaxTags.js
	}

	if (term.length >= 1 && kCode != 40){  // user has not pressed the down-arrow, load results
		results = true;
		tab = 0;
		html = createTable(tagArr, term, numResults);	//Create a Table for the results
		$("tagResults").innerHTML = html;
	}
}

//=================================================================================







