<!-- Please view the readme for more information about configuration -->
<html>
<head>
	<title>Tag That</title>
  <style type="text/css" media="all">@import "Include/Global.css";</style>
  <!-- These files should be called in the head or near the top of the body, definitely before the CurrentTags' Div -->
	<script type="text/javascript" src="Javascript/Globals.js"></script>
  <script type="text/javascript" src="Javascript/TrapKeys.js"></script>
  <script type="text/javascript" src="Javascript/AjaxTags.js"></script>
  <script type="text/javascript" src="Javascript/Js_Tags.js"></script>
</head>
<body>
<h1>Tag That</h1>
<?php
if (isset($_POST["tags"])){ 
	echo "<p>Tags that were submitted: <strong>" . $_POST["tags"] . "</strong></p>";
}
?>
<?php 
//tags = GetTags(Item_ID) 'A function that could be called to get the current tags for the item that is being edited 

//Tags should be comma delimited, here is a sample tag string.  Since the string is comma delimited, the data should not contain commas or escape these somehow.
$tags = "";
if (isset($_POST["tags"])){ 
	$tags = $_POST["tags"];
} else {
	$tags = "ab,abc,abcd,ad,bcd,de,cde,ced,edg,,,,";
}
?>
<form method="post">

<!-- The Current Tags Div houses the tags that a user is going to add for the item -->
<div id="CurrentTags" style=""><?php
$k = 0;
if ($tags <> ""){
  $tagArr = explode(",", $tags);
 	$tag = "";
  foreach($tagArr as $tag){
    $tag = trim($tag);
    if ($tag <> ""){
  ?>
  <!-- This is an individual box for each tag, there is an image so that users can remove a tag if they want to -->
  <span id="TagBox<?php echo $k; ?>" class="TagBox" style="">
		<?php echo $tag; ?> <!-- This is the tag name, the one that will be submitted -->
    <a href="#" onClick="removeStoryTag(<?php echo $k; ?>); return false;"> <!-- The link that removes the tag/box when clicked -->
      <img id="Close_Box_Image<?php echo $k; ?>" border="0" width="10" height="10" /> 
    </a>
    <input type="hidden" id="HiddenTag<?php echo $k; ?>" value="<?php echo $tag; ?>" /> <!-- The form element that is passed in the form -->
    <script type="text/javascript">
			// You could specify the image location quite easily up in the image tag but this just makes it easier to configure by allowing javascript to take care of everything
			$("Close_Box_Image<?php echo $k; ?>").src=ImageLocation;
		</script>
  </span>  
<?php		$k = $k + 1;
    }	
  }
} ?></div>

<script type="text/javascript">
  var CurrentTagNumber = <?php echo $k; ?>;	//Used for adding new tags
</script>

<input type="hidden" name="tags" id="tags" value="<?php echo $tags;?>" />
<input type="text" name="tagsText" id="tagsText" size="50" maxlength="100"
  autocomplete="off"
  value="Enter Story Tags (comma delimited)"
  onfocus="if (gotTags == false){this.value=''; this.style.color=DefaultSearchBoxTextColor; } gotTags = true;" 
  onkeyup="loadResults(this.value, numResults, event);"
  onclick="if (results && tab != 0){$('tr'+tab).style.backgroundColor=inactiveColor;tab=0;}"
/><button onClick="addStoryTag(); return false;">Add</button>
<div id="tagResults" style="style:none;">
</div>

<input type="submit" name="btn" value="Submit Tags" />
</form>
<script type="text/javascript">
RemoveEmptyCommas()				//See Globals.js
//The call to set up the tag tree after load
window.onload = getTags;	//See AjaxTags.js
</script>
</body>
</html>