=================================
Tag That
=================================
Version 1.0
Programming done by Adam Maus
"Sponsored" by the Center for Health Enhancement Systems Studies
Feel free to adapt this code anyway you please

This has been tested and works in IE7, Firefox 3.5, Chrome 3.0, Safari 3.0.3, Opera 9.52

=================================
Installation:
=================================

When you implement this module, you will have to adjust some things accordingly.

1)  You must be using VB.NET

2)  Include/GetTags.aspx uses a test string array, if you are calling from a database, you must specify the tags you want here.  A datareader, dr, is in place if you need it.  If you want to manually specify the tags, use strArr.
    a)  This module also lets you specify the current tags for an item (if there are any).

3)  Look at the "Things to Consider" section and check Javascript/Globals.js for configuration (very little to none is required)

4)  Be sure to check the Include/Global.css file to change any styling.  If you want inline styles, change the TagBox styles in index.aspx

=================================
Files:
=================================

index.aspx 	Demo Page
Globals.js 	A global functions file, functions that are used in more than one place
		are stored here.
AjaxTags.js 	Functions that control the collection of tags from the database
getTags.aspx	Page that collects and builds the tree for the tags
		Edit this page to include tags from a database
TrapKeys.js	Functions that control how keyboard commands are processed
Js_Tags.js	Functions that control how the tags are processed and presented
Global.css	The style sheet

=================================
How This Program Works:
=================================

1)  User enters the page
    a)  The tags for a given item are collected and displayed
    b)  After page load:  getTags() is called, a call to GetTags.aspx
    c)  Tags are taken from the database and made into a character-by-character tree
    d)  After the tree is made, the response javascript is evaluated and accessible to the browser
2)  User chooses to remove a tag
    a)  The span "tagBox" is removed and the tag is removed from the hidden input field Tags, all extra commas are removed
3)  User chooses to add a tag and starts to type
    a)  Each letter makes a returns some results (if there are any).  The tree is searched and possible future tags are displayed.  These tags are from the database.
    b)  The user can then use the keyboard or click on a tag and a span for that tag is made, and the tag is added to the hidden input field Tags.
    c)  The user can also press enter or add the tag manually using the button

=================================
Things to Consider:
=================================

1)  This is only for a small database with a couple hundred tags.
    If you design a scalable solution, I would like to see it.
2)  Misspelled tags are not corrected
3)  An individual tag cannot have a comma in it, but it can have any other character in 
it

=================================
Bugs: None found yet
=================================

I do not claim any responsibility for misuse of this code

Last Updated:  December 21, 2009
